#  Write a Python program to create a simple calculator that takes two numbers (num1 and num2) and an operator (+, -, *, /) as input from the user. Perform the corresponding operation based on the given operator using elif statements

# num1=int(input("Enter your number 1  : ")) # 2
# op =input("Enter your operator : ") #-
# num2=int(input("Enter your number 2 : ")) #2 


# if op == "+":
#     print(f"sum of two given number is : {num1+num2}")

# elif op == '-':
#     print(num1-num2)
    
# elif op == '*':
#     print(num1*num2)
    
# elif op == "/":
#     print(num1/num2)
    
# else:
#     print("invalid operator,please try again !!!") 


#  check given number is palindrome or not

#malayalam


# Write a program to return the grade of a person according to the marks they received.  
# Example:

# input: Enter your marks: 90
# Output : Distinction

# result={
#     "math": float(input("Enter  your math  marks : ")), #50
#     "science":float(input("Enter  your science  marks : ")), #50
#     "social":float(input("Enter  your social marks : ")), #50
#     "nepali":float(input("Enter  your nepali  marks : ")),#50
#     "english":float(input("Enter  your English marks : ")), #50
# }

# obtain marks /total marks * 100 #250/5 -->50

# marks = sum(result.values())/len(result)

# print("your marks is ",marks)

# if marks>= 90:
#     print("Grade A")
    
# elif marks >= 80:
#     print("grade B")
    
# elif marks >= 70:
#     print("Grade C")
    
# elif marks >=60:
#     print("Grade D")
    
# else:
#     print("Fail")


# word=121

# if str(word) == str(word)[::-1]:
#     print("yes, It is palindrome ",word)
# else :
#     print("No")
    
# print(type(word))



a,b="23" #a="2",b="3"
b,c="67" #b="6" c="7"


print(a+b+c)

#1.error
#2.2367
#3.267
#4.237 



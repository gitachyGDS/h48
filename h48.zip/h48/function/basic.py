#function: block of code that perform some specific task whenever we call it 

#type of function :
#built in function : pre-define or precodded by python
#print,len,max,min,str,int,range etc ..

#user define function :  these are functiopn that you define by yourself using def keyword

'''
syntax:
def function_name():
   block of code (body of code )
   
function_name() #calling function
'''

# def show():
#     print("hello sipalay")
#     print(" i want to learn django")
    
# print("--------------------------")
# show()


# print("some imp code is here")

# show()

'''
def function_name(formal argument):
   body of code
   
function_name(actual argument)

'''
    
# def show(x,y):  #a=2,b=3
#     c=x+y
#     print("sum of two number is ",c)
    
    
# show(2,3)



# show(33,7)



# return statement :it used to exit a function and return or print some result 

# def show(a):
    
#     return a+1    
# print(show(4))


# #end the function excution
# #return show only when we print
# #without any expression,then none value return


# a=[1,2,3,4]
# print(sum(a))

# def show(a,b):
#     return a+b 

# print(show(2,3))
    











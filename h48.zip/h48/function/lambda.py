#lambda function : it is similar to user define function but without name
#small anonymous function
#one line function

#avoid : only one expression ,cannot have complex logic or loop 

# syntax :
# lambda argument : expression

# def show(n):
#     return n+6

# print(show(5))

# var=lambda n : n+6
# print(var(5))

# def show(a,b):
#     return (a+b)/2

# print(show(2,3))


# v=lambda a,b,c:(a+b)/2+7+c/3
# print(v(10,20,40))

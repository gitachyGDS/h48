print("hello world") #print is an inbuilt function which is used to display message in your console(terminal)
print("hello sipalaya,i want to learn python with django")
# print("sujan"+2)

# comment  -->text in the code that is not excuted by the python (ignore by python interpreter)

#puropse of comment :
# use for documentation
#use for readability
#debugging

#type of comment :
# single line comment --> it is repersent by hash(#)
# multiline comment
"""
asfs
asfasfdsd
asdfdasf
asfdasdf
asfdas
asdfd
asdf

"""


#syntax : set of rule or protocol that define program should be written

#python interpreter(how does python work?)
print("hello sipalaya")

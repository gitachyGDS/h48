# from module.file import names

# print(names)
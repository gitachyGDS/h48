#while loop : run until condition is true


# syntax :
# while condition:
#     block of code 

# a=0 #initial condition

# while a<5: #stop condition
#     print("sujan",a)
    
#     a+=1 #step


#sujan
#sujan
#sujan
#sujan
#sujan

# import time 

# start=time.time()
# for i in range(1000000):
#     pass
# end=time.time()
# print("for loop",end-start)



# start=time.time()
# i=0
# while i<1000000:
#     i+=1
    
# end=time.time()
# print("while loop",end-start)




secret="sujan"

guess="" #sujan

while secret !=guess:
    guess=input("Enter your guess :") #sujan
    
else:
    print("your guess is correct")
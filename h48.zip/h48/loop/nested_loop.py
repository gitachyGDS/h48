# nested loop

# a=['sujan',"ram","hari"]

# for i in a:
#     print(i) #sujan
    
#     for j in i:
#         print(j)
        

# a=[1,2,3,4,5]
# b=[2,4,6,8,10]

# for i in a:
    
#     for j in b:
#         if i==j:
#             print(i)

# v=[4,2,3,1,5,8,7,6,1]


# a=2
# b=3

# a,b=b,a
# print(b)

    



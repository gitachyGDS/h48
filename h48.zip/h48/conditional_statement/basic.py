#conditional statement :Making decision based on value of variable hold or result
'''
if statment :
syntax :
if condition(True|False):
   #block of code 
   
#if else statment

if conditon:
   block of code
   
else:
  block of code 


'''

# price=10

# if price>20:
#     print("i can go to coffee shop")
#     print("okey")
    
# print("welcome")

# age=int(input("Enter your age : "))


# if age>= 18:
#     print("your are eligible to vote")
    
# else:
#     print(" you cannot vote")

#if statment in single line
# a=10
# if a>15:print("a is greater than 15")

#shorthand if-else statment (Ternary operatory)

# a=10

# # if a>15:
# #    print("a is greter than 15")
   
# # else:
# #    print("a is less than 15")

# print("a is greater than 15") if a>15 else print("a is less than 15")


# elif statement 
'''
sytnax :
if condition:
   block of code
elif condition:
   block of code
elif condition:
   block of code
   
else:
    block of code

'''

# nested if statment 

# print("bus ticket system")

# age=int(input("Enter your Age : ")) #30

# if age <= 12:
#    print(" your are free to travel ")
   
# elif age>12 and age<18:
#    print("you have to pay Rs. 20")
   
# elif age>=18 and age <40:
#    if age == 30:
#       print("you donot have to pay....")
      
#    else:
#       print("you have to pay Rs 100")

# else:
#    print("you have to Pay Rs. 50")   
   
   
   

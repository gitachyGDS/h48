#escape character : 
#\n -->new line 
# print("hello sujan \n, i want to\n learn django")

#\t -->new tab  0,8,16,24,32

# print("hello sujan")

#\b -->backspace 
# print("my name is \b\b\bsujan")

#\r -->carriage return 
# print("helloui \rworld")

# import time

# for i in range(5,0,-1):
#     print(f"count down {i}\r",end=" ")
#     time.sleep(1)
    
    
#\
# print('what\'s up ')
# print("he said , \"hello sipalaya\"")

#\\ --> america\nepal\taiwan
print("america\\nepal\\taiwan")


#\v,\f,\000,\x41
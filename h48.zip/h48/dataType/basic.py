#data types : classification of data which variable hold 

# numeric data types  : int,float,complex
#sequence data type : str,list,tuple,range
#set: set,flozenset
#map : dictionary 
#boolean data types 
# binary data types : byte ,bytearray,memoryview
#none data types 


#numeric data type :it represent  only a number 
#integer -->int : it represent  number , but cannot be decimal
#float --> it represent in decimal
#complex number --> combination of real number and imaginary number 
# a=12+4j
# print(type(a))


#dynamic typed language and static typed language 
#dynamic typed langauge : it determine data type of variable during runtime

# a:int="sujan"
# print(type(a))

# 
a=30
a=77

print(id(a))
print(a)
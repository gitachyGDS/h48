#tuple : collection of data items(data structure) which is immutable(unchangeable), order and allow duplicate value

a=("sujan","ram",66,4.5,"sujan")

# print(len(a))
# print(type(a))
# print(a)

# print(a[-1])
# print(a[1:3])

# print(a.index("sujan"))
# print(a.count("sujan"))
# print(a)

# difference between tuple and list

#list :we can modifiy or update data,[],performance is slower  due to mutable
#tuple :we cannot modify or update data,(), perfromance is faster as compare to list

#unpack tuple
# a="sujan","ram","hari"
# print(a)
# print(type(a))

# a,*b=1,2,3,4,5

# print(a)
# print(b)


# a=([1,2,3])
# print(type(a))
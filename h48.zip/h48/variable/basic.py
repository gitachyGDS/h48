#variable : container which hold data or information
# a="hello , i want to learn python with django"

# print(a)
# print(a)

# name="sujan"
# age=99 

# print("my name is ",name,"my age is ",age)

#naming variable rules : 
#variable name must be start with letter or underscore but cannot be number 
#variable name cannot be any reserved keyword
#python is case sensitive
#variable name cannot be any spical character(@#$%^&<>?)
# import keyword
# print(keyword.kwlist)
# my name="asdf"

# print="hello"
# print(print)

# multi-culture case
# myvarname="sujan"

# camel case 
# myVarName="sujan"

# #pascal case 
# MyVarName="sujan"

# #snake case 
# my_var_name="sujan"

# # pep-8

# PI=3.14

# input --> it is inbuilt function  which is used to accept value(keyword) from user
name=input("Enter your name : ")

print("my name is ",name)




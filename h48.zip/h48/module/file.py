names=["sujan","ram","hari","manoj"]

def show(a,b):
    return (a+b)/2



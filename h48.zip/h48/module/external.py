'''
pip :python package manager


'''

# pip install qrcode 
import qrcode

# pip install pillow

# qr=qrcode.make("my name is sujan")

# qr.save("sujan.png")

# qr=qrcode.QRCode(version=1,box_size=40,border=4)
# qr.add_data("https://www.facebook.com/sujan.thadarai")
# qr.make(fit=True)
# q=qr.make_image(fill_color="blue",back_color='yellow')
# q.save("sujan.png")